// import { Calendar } from '/node_modules/@fullcalendar/core/main.js';
// import dayGridPlugin from '/node_modules/@fullcalendar/daygrid/main.js';
// import timeGridPlugin from '/node_modules/@fullcalendar/timegrid/main.js';
// import listPlugin from '/node_modules/@fullcalendar/list/main.js';
import 'https://portal.dazzle.website/node_modules/@vaadin/vaadin-dialog/vaadin-dialog.js';
import './dz-booking-popup.js';


